﻿using APPR_POE_Part_1.Models;
using FluentAssertions;
using FluentAssertions.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Final_Unit_Test.Disaster
{
    public class Donation
    {
        
        [Fact]
       public void goodsDonation_SendDonation_ReturnString()
        {
            //Arrange - Our variables and classes that will be captured from our main project.
            var newDonations = new goodsDonation();

            //Act:
            var result = newDonations.SendDonation();

            //Assert:
            result.Should().NotBeNullOrWhiteSpace();
            result.Should().Be("Success: Donation Sent!");
            result.Should().Contain("Success", Exactly.Once());

        }
        [Theory]
        [InlineData(1, 1, 2)]
        [InlineData(2, 2, 4)]

        public void goodsDonation_DonationTimeout_ReturnInt(int a, int b, int expected)
        {
             //Arrange:
            var newDonations = new goodsDonation();

            //Act:
            var result = newDonations.DonationTimeout(a, b);

             //Assert:
            result.Should().Be(expected);
            result.Should().BeGreaterThanOrEqualTo(2);
            result.Should().NotBeInRange(-10000, 0);
        }

        

    }
}
