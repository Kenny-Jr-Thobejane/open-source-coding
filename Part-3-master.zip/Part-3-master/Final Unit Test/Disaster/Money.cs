﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using APPR_POE_Part_1.Models;
using FluentAssertions;
using FluentAssertions.Extensions;

namespace Final_Unit_Test.Disaster
{
    public class Money
    {
        [Fact]
        public void MoneyDonator_SendMoney_ReturnString()
        {
            //Arrange - Our variables and classes that will be captured from our main project.
            var newMoney = new MoneyDonator();

            //Act:
            var result = newMoney.SendMoney();

            //Assert:
            result.Should().NotBeNullOrWhiteSpace();
            result.Should().Be("Success: Money Sent!");
            result.Should().Contain("Success", Exactly.Once());

        }
        [Theory]
        [InlineData(1, 1, 2)]
        [InlineData(2, 2, 4)]

        public void MoneyDonator_MoneyTimeout_ReturnInt(int x, int y, int expected)
        {
            //    //Arrange:
            var newMoney = new MoneyDonator();

            //    //Act:
            var result = newMoney.MoneyTimeout(x, y);

            //    //Assert:
            result.Should().Be(expected);
            result.Should().BeGreaterThanOrEqualTo(2);
            result.Should().NotBeInRange(-10000, 0);
        }
        
        
    }
}
