﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using APPR_POE_Part_1.Models;
using APPR_POE_Part_1.Data;

namespace APPR_POE_Part_1.Controllers
{
    public class MonetaryController : Controller

    {
        private readonly APPRPOEPart1Context _context;

        public MonetaryController(APPRPOEPart1Context context)
        {
            _context = context;
        }

        // GET: Monetary
        public async Task<IActionResult> Index()
        {
            return View(await _context.goodsDonation.ToListAsync());
        }

        // GET: Monetary/Create
        public IActionResult Create(int id = 0)
        {
            if (id == 0)
                return View(new MoneyDonator());
            else
                return View(_context.goodsDonation.Find(id));
        }

        // POST: Monetary/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("DonationDate,Amount,Donator")] MoneyDonator monetaryDonations)
        {
            if (ModelState.IsValid)
            {
                if (monetaryDonations.Donator == "@Donator")
                {
                    _context.Add(monetaryDonations);
                }
                else
                    _context.Update(monetaryDonations);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(monetaryDonations);
        }

        // POST: Monetary/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var monetaryDonations = await _context.goodsDonation.FindAsync(id);

            _context.goodsDonation.Remove(monetaryDonations);


            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }

}
