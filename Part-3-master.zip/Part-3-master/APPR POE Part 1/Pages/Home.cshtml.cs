using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace APPR_POE_Part_1.Pages
{
    public class HomeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
