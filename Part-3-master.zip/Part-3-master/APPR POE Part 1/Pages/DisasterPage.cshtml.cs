using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using APPR_POE_Part_1.Data;
using APPR_POE_Part_1.Models;

namespace APPR_POE_Part_1.Pages
{
    public class DisasterPageModel : PageModel
    {
        private readonly APPR_POE_Part_1.Data.APPRPOEPart1Context _context;

        public DisasterPageModel(APPR_POE_Part_1.Data.APPRPOEPart1Context context)
        {
            _context = context;
        }
        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]

        public Disaster Disaster { get; set; } = default!;

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
          if (!ModelState.IsValid || _context.Disaster == null || Disaster == null)
            {
                return Page();
            }

            _context.Disaster.Add(Disaster);
            await _context.SaveChangesAsync();

            return RedirectToPage("./disasterView");
        }


    }
}
