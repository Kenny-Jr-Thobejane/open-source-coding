using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using APPR_POE_Part_1.Data;
using APPR_POE_Part_1.Models;

namespace APPR_POE_Part_1.Pages
{
    public class RegisterModel : PageModel
    {
        private readonly APPR_POE_Part_1.Data.APPRPOEPart1Context _context;
        public RegisterModel(APPR_POE_Part_1.Data.APPRPOEPart1Context context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public UserDetails UserDetails { get; set; } = default!;
        
        
        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid || _context.UserDetails == null || UserDetails == null)
            {
                return Page();
            }

            _context.UserDetails.Add(UserDetails);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Login");
        }
    }
}
