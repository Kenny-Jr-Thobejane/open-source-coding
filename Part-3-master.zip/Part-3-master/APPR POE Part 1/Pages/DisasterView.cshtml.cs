using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using APPR_POE_Part_1.Data;
using APPR_POE_Part_1.Models;
using Microsoft.EntityFrameworkCore;

namespace APPR_POE_Part_1.Pages
{
    //All C# codes:
    public class DisasterViewModel : PageModel
    {
        private readonly APPR_POE_Part_1.Data.APPRPOEPart1Context _context;
        public DisasterViewModel(APPR_POE_Part_1.Data.APPRPOEPart1Context context)
        {
            _context = context;
        }

        public IList<Disaster> Disaster { get; set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.Disaster != null)
            {
                Disaster = await _context.Disaster.ToListAsync();
            }
        }
    }
}
