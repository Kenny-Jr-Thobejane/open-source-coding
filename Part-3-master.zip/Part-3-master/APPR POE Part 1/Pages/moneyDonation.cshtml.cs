using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using APPR_POE_Part_1.Data;
using APPR_POE_Part_1.Models;

namespace APPR_POE_Part_1.Pages
{
    public class moneyDonationModel : PageModel
    {
        private readonly APPR_POE_Part_1.Data.APPRPOEPart1Context _context;

        public moneyDonationModel(APPR_POE_Part_1.Data.APPRPOEPart1Context context)
        {
            _context = context;
        }
        public IActionResult onGet()
        {
            return Page();
        }
        [BindProperty]
        public MoneyDonator moneyDonator { get; set; } = default!;

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid || _context.moneyDonator == null || moneyDonator == null)
            {
                return Page();
            }

            _context.moneyDonator.Add(moneyDonator);
            await _context.SaveChangesAsync();

            return RedirectToPage("./moneyView");
        }
    }
}
