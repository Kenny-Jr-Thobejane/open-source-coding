﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using APPR_POE_Part_1.Models;

namespace APPR_POE_Part_1.Data
{
    public class APPRPOEPart1Context : DbContext
    {
        internal readonly object gdViewModel;
        internal object MoneyDonator;

        public APPRPOEPart1Context()
        {
        }

        public APPRPOEPart1Context(DbContextOptions<APPRPOEPart1Context> options)
            :base(options) 
        { 
        }

        public DbSet<APPR_POE_Part_1.Models.UserDetails> UserDetails { get; set; } = default!;
        public DbSet<APPR_POE_Part_1.Models.Login> Login { get; set; }
        public DbSet<APPR_POE_Part_1.Models.Disaster> Disaster { get; set; }
        public DbSet<APPR_POE_Part_1.Models.goodsDonation> goodsDonation { get; set; }
        public DbSet<APPR_POE_Part_1.Models.MoneyDonator> moneyDonator { get; set; }


            
    }
}
