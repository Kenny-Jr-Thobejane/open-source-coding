﻿using MySql.Data.MySqlClient;
using MySqlConnector;
using System.ComponentModel.DataAnnotations;

namespace APPR_POE_Part_1.Models
{
    public class Login
    {
        [Key]
        public string Username { get; set; }
        
        public string Password { get; set; }

        public bool AuthenticateUser()
        {
            string connectionString = "Server=tcp:kenny-computer.database.windows.net,1433;Initial Catalog=donations;Persist Security Info=False;User ID=admin1;Password=Humbo=thurm2;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

            try
            {
                using MySqlConnection connection = new MySqlConnection(connectionString);
                connection.Open();

                string query = "Select Count(*) From UserDetails Where Username = @Username AND Password = @Password";
                using MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@Username", Username);
                cmd.Parameters.AddWithValue("@Password", Password);

                int count = Convert.ToInt32(cmd.ExecuteScalar());
                return count > 0;
            }
            catch (Exception ex)
            {

                Console.WriteLine($"Error: {ex.Message}");
                return false;
            }
        
        }
    }
}
