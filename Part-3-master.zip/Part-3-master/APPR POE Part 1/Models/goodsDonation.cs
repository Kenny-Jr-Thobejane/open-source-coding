﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace APPR_POE_Part_1.Models
{
    public class goodsDonation
    {
        [Key]
        [DataType(DataType.Date)]

        public DateTime DonationDate { get; set; }

        public int Item { get; set; }
        public string Category { get; set; }
        public string DescriptionItem { get; set; }
        public string Donator { get; set; }


    //Create a send Donation method that would check all items for unit testing:
        public string SendDonation()
        {
            return "Success: Donation Sent!";
        }
    //Create a timeout method to calculate the duration runtime of the unit test for Sending Donations:    

        public int DonationTimeout(int a, int b)
        {
            return a + b;
        }

    }
}
