﻿using System.ComponentModel.DataAnnotations;

namespace APPR_POE_Part_1.Models
{
    public class MoneyDonator
    {
        [Key]
        [DataType(DataType.Date)]

        public DateTime DonationDate { get; set; }
        public decimal Amount { get; set; }
        public string Donator { get; set; }

        //Create a send Money method that would check all items for unit testing:

        public string SendMoney()
        {
            return "Success: Money Sent!";
        }

        //Create a timeout method to calculate the duration runtime of the unit test for Sending Money:
        public int MoneyTimeout(int x, int y)
        {
            return x + y;
        }

       
    }

}

