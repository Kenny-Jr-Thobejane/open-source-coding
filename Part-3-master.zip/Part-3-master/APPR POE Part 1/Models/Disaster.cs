﻿using System.ComponentModel.DataAnnotations;

namespace APPR_POE_Part_1.Models
{
    public class Disaster
    {
        [Key]
        [DataType(DataType.Date)]

        public DateTime StartDate { get; set; }
        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }
        public string Location { get; set; }
        public string Description { get; set; }
        public string Aid { get; set; }

    }
}
