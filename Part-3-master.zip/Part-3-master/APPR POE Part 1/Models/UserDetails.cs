﻿using Microsoft.Data.SqlClient;
using MySql.Data.MySqlClient;
using MySqlConnector;
using System.ComponentModel.DataAnnotations;

namespace APPR_POE_Part_1.Models
{
    public class UserDetails
    {
        private static int nextId = 1;
        private static List<UserDetails> userDatabase = new List<UserDetails>();
        [Key]
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public UserDetails()
        {
            Id = nextId;
            nextId++;
        }

        public void ConnectingString()
        {
            //All connection strings made are saved on the appsettings.json page
        }
    }
}