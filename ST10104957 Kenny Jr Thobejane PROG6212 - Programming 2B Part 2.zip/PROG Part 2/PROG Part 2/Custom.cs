﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG_Part_2
{
   public abstract class Custom
    {
        public abstract double Prog_Data();
    }
}
