﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PROG_Part_2
{
    /// <summary>
    /// Interaction logic for ReportM.xaml
    /// </summary>
    public partial class ReportM : Window
    {
        public ReportM()
        {
            InitializeComponent();
            dgReco.ItemsSource = DisplayModuleList();
        }

        private List<DataGridProperty> DisplayModuleList()
        {
            List<DataGridProperty> property = new List<DataGridProperty>();

            foreach (var j in Semester_Control.multiples)
            {
                int inde = 1;
                property.Add(new DataGridProperty() { index = inde, Code = j.getTcode(), Module = j.getTName(), NumberOFcredits = j.getTCredits(), ClassHoursPerWeek = j.getTClassHours(), NumberOFweeks = j.getTNumberOfWeeks(), SemesterStartDate = j.getDStartDate(), Hours_To_Study = j.Prog_Data() });
                inde++;
            }

            return property;
        }

        private void bGoBack_Click(object sender, RoutedEventArgs e)
        {
            Semester_Control semester_Control = new Semester_Control();
            this.Hide();
            semester_Control.Show();
        }
    }
}
