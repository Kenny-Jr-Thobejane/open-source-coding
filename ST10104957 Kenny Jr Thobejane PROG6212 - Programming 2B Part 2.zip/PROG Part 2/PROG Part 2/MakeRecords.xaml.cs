﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PROG_Part_2;
namespace PROG_Part_2
{
    /// <summary>
    /// Interaction logic for MakeRecords.xaml
    /// </summary>
    public partial class MakeRecords : Window
    {
        public MakeRecords()
        {
            InitializeComponent();
            Add();
        }

        private void Add()
        {
            foreach (var j in Semester_Control.multiples)
            {
                cmbModule.Items.Add(j.getTNameAndtCode());
            }
        }

        protected string ModName;
        protected int numOfHours;
        protected DateTime timeDate;
        public static List<Finalize> finalizes = new List<Finalize>();

        private void bSub_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ModName = cmbModule.Items.GetItemAt(cmbModule.SelectedIndex).ToString();
                numOfHours = Convert.ToInt32(txtHours.Text);
                timeDate = Convert.ToDateTime(DPDate.ToString());

                RetriveRow(ModName);

            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString());
            }

        }
        protected double updated = 0.0;
        private void RetriveRow(string t_Name)
        {

            foreach (var j in Semester_Control.multiples)
            {
                List<Row> row = new List<Row>()
                {
                    new Row()
                    {
                        tCodeAndName=j.getTNameAndtCode(),
                        selfHours=j.Prog_Data()
                    }
                };
                var matcherr = from table in row
                               where table.tCodeAndName == t_Name
                               select table;

                foreach (var k in matcherr)
                {
                    updated = Convert.ToDouble(j.Prog_Data() - numOfHours);
                }

            }
            finalizes.Add(new Finalize(t_Name, numOfHours, timeDate, updated));
            MessageBox.Show("All Module Data Is Stored");
            txtHours.Clear();

            cmbModule.Focus();
            txtHours.Focus();
            DPDate.Focus();
        }

        private void bRecords_Click(object sender, RoutedEventArgs e)
        {
            Finalized_Report finalized = new Finalized_Report();
            this.Hide();
            finalized.Show();
        }
    }
}
