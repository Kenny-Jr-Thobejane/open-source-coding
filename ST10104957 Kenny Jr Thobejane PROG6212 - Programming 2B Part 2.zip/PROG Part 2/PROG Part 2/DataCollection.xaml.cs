﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace PROG_Part_2
{
    /// <summary>
    /// Interaction logic for DataCollection.xaml
    /// </summary>
    public partial class DataCollection : Window
    {

        
        public DataCollection()
        {
            InitializeComponent();
            
        }

        //Create SQLConnection:
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-QK87OS12\\SQLEXPRESS;Initial Catalog=DataCollectDB;Integrated Security=True");
        SqlDataAdapter adapt;
        SqlCommand command;

        int Id = 0;
        
        private void btn_InsertData_Click(object sender, RoutedEventArgs e)
        {
            if (txt_username.Text != "" && pb_password.Password != "")
            {
                command = new SqlCommand("Insert into Register(username,password) values(@username,@password)", conn);
                conn.Open();
                command.Parameters.AddWithValue("@username", txt_username.Text);
                command.Parameters.AddWithValue("@password", pb_password.Password);
                command.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Data inserted successfully");
                View_Data();

            }
            else
            {
                MessageBox.Show("Data inserted incorrectly, try again!");
            }
        }
        //Display the data in DataGrid:
        private void View_Data()
        {

            conn.Open();
            DataTable table_ = new DataTable();
            adapt = new SqlDataAdapter("Select * from Register", conn);
            adapt.Fill(table_);
            Datagrid.ItemsSource = table_.DefaultView;
            conn.Close();
        }

        private void btn_Search_Click(object sender, RoutedEventArgs e)
        {
            conn.Open();
            string addQuery = "Select * from Register where username=@username";
            SqlDataAdapter adapt = new SqlDataAdapter(addQuery, conn);
            adapt.SelectCommand.Parameters.AddWithValue("@username", txt_Search.Text.Trim());
            DataTable dataTable = new DataTable();
            adapt.Fill(dataTable);
            conn.Close();
            if (dataTable.Rows.Count > 0)
            {
                Datagrid.ItemsSource = dataTable.DefaultView;
            }
            else
            {
                MessageBox.Show("No rows were found, try again!");
                Datagrid.ItemsSource = null;
                conn.Close();
            }
        }

        private void Datagrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }

        private void btn_UpdateData_Click(object sender, RoutedEventArgs e)
        {
            if (Datagrid.SelectedItems.Count > 0)
            {
                conn.Open();

                DataRowView _rowView = (DataRowView)Datagrid.SelectedItem;
                string username = _rowView.Row[0].ToString();
                command = new SqlCommand("Update Register set password=@password Where username=@username", conn);
                command.Parameters.AddWithValue("@username", txt_username.Text);
                command.Parameters.AddWithValue("@password", pb_password.Password);
                command.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Data updated successfully!");
                View_Data();
            }
            else
            {
                MessageBox.Show("No updates were found, try again!");
            }
        }

      

        private void txt_Search_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            while (Datagrid.SelectedItems.Count >= 1)
            {
                DataRowView views = (DataRowView)Datagrid.SelectedItem;
                views.Row.Delete();
            }
        }
    }
}
