﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PROG_Part_2
{
    /// <summary>
    /// Interaction logic for Finalized_Report.xaml
    /// </summary>
    public partial class Finalized_Report : Window
    {
        public Finalized_Report()
        {
            InitializeComponent();
            dgReco.ItemsSource = DisplayModuleList();
        }
        private List<FinalizedGrid> DisplayModuleList()
        {
            List<FinalizedGrid> property = new List<FinalizedGrid>();

            foreach (var j in MakeRecords.finalizes)
            {
                int inde = 1;
                property.Add(new FinalizedGrid() { index = inde, ModuleAndCode = j.getModuleName(), ClassHoursPerWeek = j.getClassHours(), DateOFStudy = j.getStartDate(), HoursRemainingToStudy = j.Prog_Data() });
                inde++;
            }

            return property;
        }

        private void bGo_Back_Click(object sender, RoutedEventArgs e)
        {
            MakeRecords semester_Control = new MakeRecords();
            this.Hide();
            semester_Control.Show();
        }

        private void dgReco_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
