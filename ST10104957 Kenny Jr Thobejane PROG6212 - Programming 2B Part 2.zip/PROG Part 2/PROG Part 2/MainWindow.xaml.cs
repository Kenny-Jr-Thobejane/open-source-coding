﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PROG_Part_2;

namespace PROG_Part_2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        //create variables to store data:
        protected string selectCode, selectName, combine;
        protected int selectCredits, selectHours;

        private void btn_Register_Click(object sender, RoutedEventArgs e)
        {
            DataCollection dataCollection = new DataCollection();
            this.Hide();
            dataCollection.Show();
           
        }

        private void bMove_Click(object sender, RoutedEventArgs e)
        {
            Semester_Control semester_Control = new Semester_Control();
            this.Hide();
            semester_Control.Show();
        }


        //create an array list to store the data temporarily:
        public static List<Temporary> collect = new List<Temporary>();

        private void bSub_Click(object sender, RoutedEventArgs e)
        {
            //use a try exception to collect, sellect and store data:
            try
            {
                selectCode = txt_ModuleCode.Text.ToString();
                selectName = txt_ModuleName.Text.ToString();
                selectCredits = Convert.ToInt32(txt_Credits.Text);
                selectHours = Convert.ToInt32(txt_Hours.Text);
                combine = selectName.ToString() + "-" + selectCode.ToString();
                collect.Add(new Temporary(selectCode, selectName, selectCredits, selectHours, combine));
                MessageBox.Show("All Module Data Has Been Stored.");

                txt_ModuleCode.Clear();
                txt_ModuleName.Clear();
                txt_Credits.Clear();
                txt_Hours.Clear();

                txt_ModuleCode.Focus();
                txt_ModuleName.Focus();
                txt_Credits.Focus();
                txt_Hours.Focus();

            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString());
            }
        }
    }
}
