﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PROG_Part_2;

namespace PROG_Part_2
{
    /// <summary>
    /// Interaction logic for Semester_Control.xaml
    /// </summary>
    public partial class Semester_Control : Window
    {
        public Semester_Control()
        {
            InitializeComponent();
        }

        private DateTime d_Date;
        private int t_weeks;
        public static List<Multiple> multiples = new List<Multiple>();

        private void bSub_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                d_Date = Convert.ToDateTime(D_Date.ToString().Trim());
                t_weeks = Convert.ToInt32(tNumberWeeks.Text.Trim());
                foreach (var j in MainWindow.collect)
                {
                    multiples.Add(new Multiple(j.getTcode(), j.getTName(), j.getTCredits(), j.getTClassHours(), t_weeks, d_Date, j.getTNameAndtCode()));
                }
                MessageBox.Show("Semester Data Is Stored");
                tNumberWeeks.Clear();

                D_Date.Focus();
                tNumberWeeks.Focus();

            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString());
            }

        }

        private void bMove_Click(object sender, RoutedEventArgs e)
        {
            ReportM reportM = new ReportM();
            this.Hide();
            reportM.Show();
        }

        private void bMake_Click(object sender, RoutedEventArgs e)
        {
            MakeRecords makeRecords = new MakeRecords();
            this.Hide();
            makeRecords.Show();
        }
    }
}
