﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG_Part_2
{
    public class DataGridProperty
    {
        public int index { get; set; }
        public string Code { get; set; }
        public string Module { get; set; }
        public int NumberOFcredits { get; set; }
        public int ClassHoursPerWeek { get; set; }
        public int NumberOFweeks { get; set; }
        public DateTime SemesterStartDate { get; set; }
        public double Hours_To_Study { get; set; }
    }
}
