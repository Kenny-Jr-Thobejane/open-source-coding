﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG_Part_2
{
    public class Multiple : Custom
    {
        private string tCode, tName, tNameAndtCode;
        private int tCredits, tClassHours, tNumberOfWeeks;
        private DateTime dStartDate;
        protected double result;

        public Multiple()
        {

        }
        public override double Prog_Data()
        {
            result = ((getTCredits() * 10) / getTNumberOfWeeks() - getTClassHours());
            return Convert.ToDouble(result);
        }
        public Multiple(string tcode, string tName, int tcredits, int tClassHours, int tNumberOfWeeks, DateTime dStartDate, string tNameAndtCode)
        {
            this.tCode = tcode;
            this.tName = tName;
            this.tCredits = tcredits;
            this.tClassHours = tClassHours;
            this.tNumberOfWeeks = tNumberOfWeeks;
            this.dStartDate = dStartDate;
            this.tNameAndtCode = tNameAndtCode;
        }

        public void setTcode(string TCode)
        {
            this.tCode = TCode;
        }
        public string getTcode()
        {
            return this.tCode;
        }
        public void setTNameAndtCode(string tNameAndtCode)
        {
            this.tNameAndtCode = tNameAndtCode;
        }
        public string getTNameAndtCode()
        {
            return this.tNameAndtCode;
        }
        public void setTname(string Tname)
        {
            this.tName = Tname;
        }
        public string getTName()
        {
            return this.tName;
        }
        public void setTCredits(int tCredits)
        {
            this.tCredits = tCredits;
        }
        public int getTCredits()
        {
            return this.tCredits;
        }
        public void setTClassHours(int tClassHours)
        {
            this.tClassHours = tClassHours;
        }
        public int getTClassHours()
        {
            return this.tClassHours;
        }
        public void setTNumberOfWeeks(int tNumberOfWeeks)
        {
            this.tNumberOfWeeks = tNumberOfWeeks;
        }
        public int getTNumberOfWeeks()
        {
            return this.tNumberOfWeeks;
        }
        public void setDStartDate(DateTime dStartDate)
        {
            this.dStartDate = dStartDate;
        }
        public DateTime getDStartDate()
        {
            return this.dStartDate;
        }
    }
}