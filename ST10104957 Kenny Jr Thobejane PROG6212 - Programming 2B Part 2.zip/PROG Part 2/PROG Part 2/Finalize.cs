﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG_Part_2

{
    public class Finalize : Custom
    {
        private string moduleName;
        private int classHours;
        private DateTime StartDate;
        private double remainder;
        protected double x;

        public override double Prog_Data()
        {
            return remainder;
        }
        public Finalize(string tName, int tClassHours, DateTime dStartDate, double remainder)
        {
            this.moduleName = tName;
            this.classHours = tClassHours;
            this.StartDate = dStartDate;
            this.remainder = remainder;
        }
        public void setModuleName(string TName)
        {
            this.moduleName = TName;
        }
        public string getModuleName()
        {
            return this.moduleName;
        }
        public void setClassHours(int tClassHours)
        {
            this.classHours = tClassHours;
        }
        public int getClassHours()
        {
            return this.classHours;
        }
        public void setStartDate(DateTime dStartDate)
        {
            this.StartDate = dStartDate;
        }
        public DateTime getStartDate()
        {
            return this.StartDate;
        }
    }
}