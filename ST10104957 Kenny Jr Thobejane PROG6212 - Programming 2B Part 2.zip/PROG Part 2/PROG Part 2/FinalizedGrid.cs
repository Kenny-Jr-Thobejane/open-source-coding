﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG_Part_2
{
    class FinalizedGrid
    {
        public int index { get; set; }
        public string ModuleAndCode { get; set; }
        public int ClassHoursPerWeek { get; set; }
        public DateTime DateOFStudy { get; set; }
        public double HoursRemainingToStudy { get; set; }
    }
}
