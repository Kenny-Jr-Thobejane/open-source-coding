﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG_Part_2
{
   public class Row
    {
        public string tCodeAndName { get; set; }
        public double selfHours { get; set; }
    }
}
