******************************************************************
***************            READ ME !!!!!!	******************

1. HOW TO RUN THE APP
	1.1 EXTRACTION
	- You may extract the file from the zip folder provided to you and use and extraction software to access it (etc. 7Zip, WinRaR) 
	
	1.2 EXECUTION 
	- Once Execution begins, it will open the main window. On the main window (Multiple Modules), you enter the module code, module name, credit number and class hours per week.
	Then you choose to capture the data to store the data.
	
	- CLick Next Page to proceed.

	- If you select the next Page, you may enter the number of weeks in a semester and the start date of the semester.
	You must select capture data to store the number of weeks in a semester and the start date of the semester.
	You may select Module Report to display the data captured or select Time Schedule to determine your study time.   
	
	- If you selected Time Schedule, Select the module you have stored to determine a timeframe.
]	- Select a Date to study the module.
	- Enter the number of hours you will study for the module.
	- Select Capture to store the data.
	- Select Finalized Report to print the final report of the data you have stored

	-The program will execute all the modules you have inserted into the programme :)   

	//If the user selected Register:
	- As stated on the program, the user may select 
  
 

2. PURPOSE OF THE APP
	- The purpose of this application is to assist students with their time management skills and optimize their studying time
	- The application will calculate how much hours a student should study for a module based on the amount of credits and weekly class hours.

3. EXPECTED ERRORS
	-There could be a possibility that the buttons might not work to proceed to the next window.
	-For adding details into the database, there could be a possible error asking for a opening or closing connection. 

4. EXTRA RESOURCES
	4.1 CLASS DIAGRAM - Word Document called UML Diagram contains two classes.
	

5.AUTHOR DETAILS
	5.1 Kenny Jr Thobejane
	5.2 ST10104957
	5.3 ST10104957@rcconnect.edu.za/kthobejane16@gmail.com

