/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function myFunction(images) {
  // Get the expanded image
  var p = document.getElementById("p");
  // Get the image text
  var imgText = document.getElementById("imgtext");
  // Use the same src in the expanded image as the image being clicked on from the grid
  p.src = images.src;
  // Use the value of the alt attribute of the clickable image as text inside the expanded image
  imgText.innerHTML = images.alt;
  // Show the container element (hidden with CSS)
  p.parentElement.style.display = "block";
}
function reset(){
    var x , y , z;
    x = document.getElementById("firstname").value="";
    y = document.getElementById("lastname").value="";
    z = document.getElementById("email").value="";
}

