﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POE_Part_1_Practise_
{
    class Bread_Eggs_and_Milk : Class2
    {
        public void food()
        {
            Console.WriteLine("The end-user specifically buys bread, eggs and milk.");
        }
    }
}
