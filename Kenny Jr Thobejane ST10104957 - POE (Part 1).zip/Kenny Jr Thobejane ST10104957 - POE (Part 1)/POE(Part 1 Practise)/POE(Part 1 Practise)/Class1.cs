﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POE_Part_1_Practise_
{
    class Class1
    {
        private int grossMonthlyPay;
        private double taxDeductions;
        private String monthlyExpenditures;
        //Create Getters and Setters:
        public int grossPay
        {
            get { return grossMonthlyPay; }
            set { this.grossMonthlyPay = value; }
        }
        public double tax
        {
            get { return taxDeductions; }
            set { this.taxDeductions = value; }
        }
        public String expenditures
        {
            get { return monthlyExpenditures; }
            set { this.monthlyExpenditures = value; }
        }
       
        
        
        
    }
    
    

}
