﻿using System;

namespace POE_Part_1_Practise_
{
    public abstract class Expense
    {
        //Create private variables for expenses:
        private double grossSalary;
        private double taxDeduction;
        private double totalAfterTax;
        
        //Create Getters and Setters for each private variable:
        public void SetGrossSalary(double salary)
        {
            this.grossSalary = salary;
        }
        public void SetTaxDeduction(double tax)
        {
            this.taxDeduction = tax;
        }
        public void SetTotalAftertax(double total)
        {
            this.totalAfterTax = total;
        }
        public double GetGrossSalary()
        {
            return this.grossSalary;
        }
        public double GetTaxDeduction()
        {
            return this.taxDeduction;
        }
        public double GetTotalAfterTax()
        {
            return this.totalAfterTax;
        }
    }
    
    class Program
    {

        static void Main(string[] args)
           {
            //Create and inheritence for Expenses:
            Class2 expense = new Class2();
            expense.Groceries();

            Class2 Bread_Eggs_Milk = new Class2();
            Bread_Eggs_Milk.Groceries();


            //Create an Array for expenses:
            String[] expenses = {"Groceries","Water and Lights","Travel Costs(Including Petrol), Cell phone and Telephone","Other Expenses"};
            String selectedItems;
            Boolean isSelectedItem;
            String selectedItem = null; 
            for (int i = 0; i < expenses.Length; i++)
            {
                if (selectedItem == expenses[i])
                {
                    isSelectedItem = true;
                    selectedItems = expenses[i];
                    i = expenses.Length;
                }
            }
            
            //Create a rent and buy method for end user to enter how they will purchase their property:


            // 1.)Create variables 
            double grossMonthlyIncome, taxDeduction, groceries, waterAndLights, travelCosts, cellAndTelephone, otherExpenses;

            string user;
            //Prompt out the values for each expenditure:
            Console.WriteLine("Enter your gross monthly income:");
            grossMonthlyIncome = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter an estimated monthly tax deduction:");
            taxDeduction = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter an estimated monthly expenditure for groceries:");
            groceries = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter an estimated monthly expenditure for water and lights:");
            waterAndLights = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter an estimated monthly expenditure for travel costs:");
            travelCosts = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter an estimated monthly expenditure for cellphone and telephone:");
            cellAndTelephone = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter an estimated monthly expenditure for other expenses:");
            
            otherExpenses = Convert.ToDouble(Console.ReadLine());
            double monthlyIncomeAfterTax = grossMonthlyIncome - taxDeduction;
            
            //Prompt out a summary for each value:
            Console.WriteLine("******************************************" + "\n" +
                              "GROSS MONTHLY INCOME: " + grossMonthlyIncome + "\n" +
                              "ESTIMATED MONTHLY TAX DEDUCTION: " + taxDeduction + "\n" +
                              "MONTHLY INCOME AFTER TAX: " + monthlyIncomeAfterTax + "\n" +
                              "******************************************" + "\n" +
                              "GROCERIES: " + groceries + "\n" +
                              "WATER AND LIGHTS: " + waterAndLights + "\n" +
                              "TRAVEL COSTS(INCLUDING PETROL): " + travelCosts + "\n" +
                              "CELLPHONE AND TELEPHONE: " + cellAndTelephone + "\n" +
                              "OTHER EXPENSES: " + otherExpenses + "\n" +
                              "******************************************");
            Console.WriteLine("Select 1. for Renting Accomodation" + "\n" + "Select 2. for Buying a Property:" + "\n" + "Select any key to cancel.");
            string RB = Console.ReadLine();
            RB = RB.ToLower();
            if (RB.Equals("1"))
            {
                rent();
            }
            else if (RB.Equals("2"))
            {
                buy();
            }
            
            //2.) Build a rent and buy methods:
            static void rent()
            {
                String user;
                double price;
                

                int rentAccomodation = 1;
                
                int rent;
                if (rentAccomodation == 1)
                {
                    Console.WriteLine("Enter the monthly rental amount:");
                    rent = Convert.ToInt32(Console.ReadLine());
                    //Prompt out a receipt for the monthly rental amount:
                    Console.WriteLine("***********************" + "\n" +
                                      "MONTHLY RENTAL AMOUNT: " + rent + "\n" +
                                      "***********************");
                }
            }
            
            static void buy()
            {
                //Let the end-user enter how much they want to buy a property:
                int buyProperty = 2;
                if (buyProperty == 2)
                {


                    double price, totalDeposit, interestRate, numOfMonthlyRepayment;
                    double payment = 0;
                    Console.WriteLine("Enter the price of the property:");
                    price = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter the total deposit:");
                    totalDeposit = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter the interest rate:");
                    interestRate = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter the number of months to repay(between 240 and 360):");
                    numOfMonthlyRepayment = Convert.ToDouble(Console.ReadLine());
                    //Calculate the monthly home loan repayment:
                    double accum = price * (1 + interestRate * numOfMonthlyRepayment);
                    

                    //Prompt out a receipt for buying a property:
                    Console.WriteLine("***************************" + "\n" +
                                      "PRICE OF THE PROPERTY: " + price + "\n" +
                                      "TOTAL DEPOSIT: " + totalDeposit + "\n" +
                                      "INTEREST RATE: " + interestRate + "%" + "\n" +
                                      "NUMBER OF MONTHS TO REPAY: " + numOfMonthlyRepayment + "\n" +
                                      "***************************");
                    //Insert if statement to determine if the end-user may apply for a home loan:
                    if (payment > 0.3333)
                    {
                        Console.WriteLine("User cannot apply for a home loan! Please go to your nearest bank for queries.");
                    }
                    else
                    {
                        Console.WriteLine("User may apply for a home loan :)");
                    }
                }
            }
            

        }
    }
}
    




        
    
    
    

