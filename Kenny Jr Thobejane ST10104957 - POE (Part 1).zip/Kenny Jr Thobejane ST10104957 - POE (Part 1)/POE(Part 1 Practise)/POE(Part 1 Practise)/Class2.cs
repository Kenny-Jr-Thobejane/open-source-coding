﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POE_Part_1_Practise_
{
    class Class2
    {
        //Create methods that will be inherited on the main class:
        public void Groceries()
        {
            Console.WriteLine("End-user pays for groceries.");
        }
        public void WaterAndLights()
        {
            Console.WriteLine("End-user pays for water and lights.");
        }
        public void TravelCosts()
        {
            Console.WriteLine("End-user pays for travel costs (including petrol)");
        }
        public void Phone()
        {
            Console.WriteLine("End" +
                "-user pays for cell and telephone.");
        }
        public void OtherExpenses()
        {
            Console.WriteLine("End-user pays for other expenses.");
        }
    }
}
