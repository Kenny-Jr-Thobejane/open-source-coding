/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question2;

/**
 *
 * @author Kenny Jr Thobejane
 */
public class VCStudent extends Student {
    //Create private variables:
    private String studentName;
    private int studentNumber;
    private String sport;
    //Create Getters for each method:

    public String getStudentName() {
        return studentName;
    }

    public int getStudentNumber() {
        return studentNumber;
    }

    public String getSport() {
        return sport;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setStudentNumber(int studentNumber) {
        this.studentNumber = studentNumber;
    }

    public void setSport(String sport) {
        this.sport = sport;
    }
//    @Override
//    public String study(){
//        return "Enjoy Studying!"; //To change body of genrated methods, choose Tools {Templates}
//    }
//    @Override
//    public String attend(){
//        return "Prefer online sessions over face to face sessions."; //To change body of generated methods, choose Tools {Templates}
//    }
//    @Override
//    public String toString(){
//        return "Name:" + getName() + "\nSurname:" + getSurname() + "\nStudent Number:" + getStudentNumber() + "\nStudy:" + study() + "\nAttend:" + attend(); 
//    }
}   
    

