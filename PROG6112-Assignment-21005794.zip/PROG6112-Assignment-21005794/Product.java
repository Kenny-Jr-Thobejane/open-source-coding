/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question.pkg1;

/**
 *
 * @author Kenny Jr Thobejane
 */
public class Product {
    //Create private classes:
    private String productCode;
    private String productName;
    private String productWarranty;
    private String productCategory;
    private double productPrice;
    private int stocklevel;
    private String supplier;
   //Create Getters for each method:
    public String getProductCode() {
        return productCode;
    }
    public String getProductName() {
        return productName;
    }
    public String getProductWarranty() {
        return productWarranty;
    }
    public String getProductCategory() {
        return productCategory;
    }
    public double getProductPrice() {
        return productPrice;
    }
    public int getStocklevel() {
        return stocklevel;
    }
    public String getSupplier() {
        return supplier;
    }
    //Create Setters for each method:
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public void setProductWarranty(String productWarranty) {
        this.productWarranty = productWarranty;
    }
    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }
    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }
    public void setStocklevel(int stocklevel) {
        this.stocklevel = stocklevel;
    }
    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }
    
    
    
}
