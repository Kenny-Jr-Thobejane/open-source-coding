/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question2;

/**
 *
 * @author Kenny Jr Thobejane
 */
public class RCStudent extends Student{
    //Create variables:
    String studentName;
    int studentNumber;
    //Create Getters for RC Students:
    public String getStudentName(){
        return studentName;
    }
    public int getStudentNumber(){
        return studentNumber;
    }
    //Create Setters for RC Students:
    public void setStudentName(String studentName){
        this.studentName = studentName;
    }
    public void setStudentNumber(int studentNumber){
        this.studentNumber = studentNumber;
    }
//    @Override
//    public String study(){
//        return "Enjoy studying!"; //To change body of genrated methods, choose Tools {Templates}
//    }
//    @Override
//    public String attend(){
//        return "Prefer face to face sessions over online sessions"; //To change body of generated methods, choose Tools {Templates}
//    }
//    @Override
//    public String toString(){
//        return "Name:" + getName() + "\nSurname:" + getSurname() + "\nStudent Number:" + getStudentNumber() + "\nStudy:" + study() + "\nAttend:" + attend(); 
//    }
}
    

