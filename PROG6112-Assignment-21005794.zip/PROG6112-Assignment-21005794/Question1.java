/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question.pkg1;
import java.util.Scanner;
/**
 *
 * @author Kenny Jr Thobejane
 */
public class Question1 {
 public static Product[] productArr = new Product[1];
 public static Products products = new Products();
 public static Scanner read = new Scanner(System.in);
        /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Create method that will read the program:
     Application();   
    }
    //Create application method:
    public static void Application(){
        String selection;
        System.out.println("WELCOME TO BRIGHT FUTURE TECHNOLOGIES APPLICATION" + "\n" +
                           "*************************************************" + "\n" +
                           "Enter (1) to launch menu or any other key to exit");
       //Use switch and break statements:
        selection = read.nextLine();
       switch (selection){
           case "1": {
               LoadMenu();
               break;
               }
           default: {
               products.exitApplication();
           }
        }   
    }
    //Create a loading method:
    public static void LoadMenu(){
        System.out.println("Please select one of the following menu items:"
                  + "\n" + "1) Capture a new product."
                  + "\n" + "2) Search for a new product."
                  + "\n" + "3) Update a product."
                  + "\n" + "4) Delete a product." 
                  + "\n" + "5) Print report."
                  + "\n" + "6) Exit Application.");
        //Use switch and break statements:
        String selection = read.nextLine();
        switch (selection) {
            case "1": {
                for (int i = 0; i < productArr.length;i++){
                    products.CaptureProduct();
                    products.SaveProduct(productArr);
                }
                LoadMenu();
                break;
            }
            case "2": {
                if (products.SearchProduct(productArr)){
                   LoadMenu();
                }else{
                    System.out.println("Search undiscoverable! Sorry.");
                    LoadMenu();
                }
                break;
            }
            case "3": {
                if(products.UpdateProduct(productArr)){
                    LoadMenu();
                }else{
                    System.out.println("Search undiscoverable! Sorry.");
                    LoadMenu();
                }
                break;
            }
            case "4": {
                if(products.DeleteProduct(productArr)){
                    LoadMenu();
                }else{
                    System.out.println("Search undiscoverable! Sorry.");
                    LoadMenu();
                }
                break;
            }
            case "5": {
                if(products.SearchProduct(productArr)){
                LoadMenu();
                }else{
                break;
                }
            }
            case "6":
                products.exitApplication();
                break;
            }
            
        
            
        
    }
}  

