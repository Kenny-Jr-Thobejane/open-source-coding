/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question2;

/**
 *
 * @author Kenny Jr Thobejane
 */
public abstract class Student {
    //Create private methods:
    private String name;
    private String surname;
    private int studentNumber;
    //Create Getters and Setters for each private method:

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public int getStudentNumber() {
        return studentNumber;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setStudentNumber(int studentNumber) {
        this.studentNumber = studentNumber;
    }
    //Create abstract methods:
    public abstract String study();
    public abstract String attend();
}

