/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question2;
import java.util.Scanner;
/**
 *
 * @author Kenny Jr Thobejane
 */
public class Question2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        Student students;
        students = new RCStudent();
        System.out.println("Please enter your name:");
        String name = read.next();
        System.out.println("Please enter your surname:");
        String surname = read.next();
        System.out.println("Please enter your student number:");
        int studentNumber = read.nextInt();
        students.setName(name);
        students.setSurname(surname);
        students.setStudentNumber(studentNumber);
        System.out.println("ROSEBANK COLLEGE:" + "\n****************************" + "\n" +students.toString());
        
        students = new VCStudent();
        students.setName(name);
        students.setSurname(surname);
        students.setStudentNumber(studentNumber);
        System.out.println("VARSITY COLLEGE:" + "\n*****************************" + "\n" + students.toString());
    
  }
    
}
