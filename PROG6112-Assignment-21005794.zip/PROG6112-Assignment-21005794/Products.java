/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question.pkg1;
import java.util.Scanner;
/**
 *
 * @author Kenny Jr Thobejane
 */
public class Products {
   //Create private Scanner and private product class:
    private Scanner read = new Scanner(System.in);
    private Product product = new Product();
    //Crearte methods for main class:
    public void CaptureProduct(){
        //User must prompt out the product:
        System.out.println("CAPTURE A NEW PRODUCT" + "\n" +
                           "**************************");
        System.out.print("Enter the product code:" );
        String code = read.nextLine();
        product.setProductCode(code);
        System.out.print("Enter the product name:" );
        String name = read.nextLine();
        product.setProductName(name);
        SelectCategory();
        SelectWarranty();
        System.out.print("Enter price for " + product.getProductName() + ": ");
        double price = read.nextDouble();
        product.setProductPrice(price);
        read.nextLine();
        System.out.print("Enter stock level for " + product.getStocklevel() + ": ");
        int stocklevel = read.nextInt();
        product.setStocklevel(stocklevel);
        }
    //User must create a save method:
    public void SaveProduct(Product[] products){
        for(int i = 0;i < products.length; i++){
            products[i] = product;
        }
    }
    public boolean SearchProduct(Product[] products){
        System.out.println("Please enter the product code to search: " + product.getProductCode() + "\n" 
                         + "***************************************************************************" + "\n"
                         + "PRODUCT SEARCH RESULTS:" + "\n" 
                         + "***************************************************************************" + "\n"
                         + "PRODUCT CODE: " + product.getProductCode() + "\n"
                         + "PRODUCT NAME: " + product.getProductName() + "\n"
                         + "PRODUCT WARRANTY: " + product.getProductWarranty() + "\n"
                         + "PRODUCT CATEGORY: " + product.getProductWarranty() + "\n"
                         + "PRODUCT PRICE: " + product.getProductPrice() + "\n"
                         + "PRODUCT STOCK LEVELS: " + product.getStocklevel() + "\n"
                         + "PRODUCT SUPPLIER: " + product.getSupplier());
        String productCode = read.nextLine();
        boolean found = false;
        for (Product Product : products){
            if(product.getProductCode().equalsIgnoreCase(productCode)){
                System.out.print("PRODUCT SEARCH RESULTS" + "\n"
                                 + "**********************************************" + "\n" 
                                 + "PRODUCT CODE: " + product.getProductCode() + "\n"
                                 + "PRODUCT NAME: " + product.getProductName() + "\n"
                                 + "PRODUCT WARRANTY: " + product.getProductWarranty() + "\n"
                                 + "PRODUCT CATEGORY: " + product.getProductCategory() + "\n"
                                 + "PRODUCT PRICE: " + product.getProductPrice() + "\n"
                                 + "PRODUCT STOCK LEVELS: " + product.getStocklevel() + "\n"
                                 + "PRODUCT SUPPLIER: " + product.getSupplier() + "\n"
                                 + "************************************************");
            }
        }
        return false;
    }
    //Create an update method:
    public boolean UpdateProduct(Product[] products){
        System.out.print("Enter the product code to update: ");
        String productCode = read.nextLine();
        boolean update = false;
        for(Product Product : products){
            if(product.getProductCode().equalsIgnoreCase(productCode)){
                System.out.print("Update the warranty? (y) Yes, (n) No");
                String warranty = read.nextLine();
                if(warranty.equalsIgnoreCase("y")){
                    SelectWarranty();
                }
                System.out.print("Update the warranty? (y) Yes, (n) No");
                String newPrice = read.nextLine();
                if(newPrice.equalsIgnoreCase("y")){
                    System.out.print("Enter new car price: ");
                    double price = read.nextDouble();
                    product.setProductPrice(price);
                }
            }
        }
    return update;
    }
    //Create a RemoveTheProduct method:
    private Product[] RemoveTheProduct(Product[] productArr, int index){
     return productArr; 
    }
    //Create a Delete method:
    public boolean DeleteProduct(Product[] product){
        System.out.println("Enter the product code to delete: ");
        String productCode = read.nextLine();
        boolean deleted = false;
        Product[] productArr = null;
        for(int x = 0; x < product.length; x++) {
           if(product[x].getProductCode().equalsIgnoreCase(productCode)){
               productArr = RemoveTheProduct(product, x);
               System.out.println("Product deleted successfully.");
               deleted = true;
               return deleted;
           }
        }
      return deleted;  
    }
    public void SelectWarranty(){
        //Prompt out for user to choose the type of warranty:
        System.out.println("Please enter the product code to update: ");
        String warranty = read.nextLine();
        //User must select if they want the warranty and create switches and breaks
        System.out.println("Update the warranty? (1)Yes, (2) No ");
        switch (warranty){
            case "1": {
                product.setProductWarranty("2 Years");
                break;
            }default: {
                product.setProductWarranty("5 Years");
            }
        }
    }
    public void SelectCategory(){
        //Prompt out the category the user will select:
        System.out.println("Select the product category: "
                  + "\n" + "Desktop Computer - 1"
                  + "\n" + "Laptop - 2"
                  + "\n" + "Tablet - 3"
                  + "\n" + "Printer - 4"
                  + "\n" + "Gaming Console - 5");
        //Create switches and breaks:
        String category = read.nextLine();
        switch (category){
            case "1": {
                product.setProductCategory("Desktop Computer");
                break;
            }
            case "2": {
                product.setProductCategory("Laptop");
                break;
            }
            case "3": {
                product.setProductCategory("Tablet");
                break;
            }
            case "4": {
                product.setProductCategory("Printer");
                break;
            }
            case "5": {
                product.setProductCategory("Gaming Console");
                break;
            }
            default : {
                System.out.println("Invalid Category type! Sorry.");
            }
        }
    }
    
    
    
    
           
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public void exitApplication(){
        System.exit(0);
    }
}
