package com.example.opsc6312p2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Species : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_species)
    }
}