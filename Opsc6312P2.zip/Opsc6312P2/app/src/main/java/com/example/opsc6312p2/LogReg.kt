package com.example.opsc6312p2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class LogReg : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log_reg)

        val buttonClick = findViewById<Button>(R.id.login_btn)
        buttonClick.setOnClickListener {
            val intent = Intent(this, login::class.java)
            startActivity(intent)

            val buttonClick = findViewById<Button>(R.id.start_btn)
            buttonClick.setOnClickListener {
                val intent = Intent(this,Register::class.java)
                startActivity(intent)
            }
        }
    }
}